import { WeddingEvent, Blessing, StoryMilestone } from '../types';

export const WEDDING_DETAILS = {
  brideName: 'Sushma',
  groomName: 'Sai Rahul',
  weddingDate: '2026-11-12T21:27:00+05:30', // 12 Nov 2026 at 9:27 PM IST
  displayDate: 'Thursday, 12th November 2026',
  muhurthamTime: '9:27 PM',
  muhurthamDetails: 'Vrishabha Lagnam Auspicious Sumuhurtham (Jeelakarra Bellam)',
  venueName: 'Sri Shubham Palace Convention & Royal Kalyana Mandapam',
  venueLocation: 'Financial District, Gachibowli, Hyderabad, Telangana 500032',
  googleMapsUrl: 'https://maps.google.com/?q=Sri+Shubham+Convention+Hyderabad',
  contactPhone: '+91 98765 43210',
  contactPhone2: '+91 98765 43211',
  parents: {
    bride: 'Smt. Padmavathi & Sri Venkata Ramana',
    groom: 'Smt. Lakshmi & Sri Satyanarayana'
  }
};

export const WEDDING_EVENTS: WeddingEvent[] = [
  {
    id: 'haldi',
    title: 'Pellikuthuru & Haldi Ceremony',
    teluguTitle: 'పెళ్లికూతురు & హల్దీ వేడుక',
    date: '2026-11-11',
    displayDate: 'Wednesday, 11th November 2026',
    time: '10:00 AM onwards',
    venue: 'Subham Garden Lawns',
    address: 'Near ORR Junction, Financial District, Hyderabad',
    description: 'The auspicious ceremony where fragrant turmeric paste and sandalwood are lovingly applied with blessings, laughter, floral petals, and folk songs.',
    attire: 'Sunny Yellows, Mustard, Floral Prints & Festive Cottons',
    attireColorHint: '#F59E0B',
    iconName: 'Sparkles',
    isMuhurtham: false
  },
  {
    id: 'sangeet',
    title: 'Mehendi & Sangeet Utsav',
    teluguTitle: 'మెహందీ & సంగీత్ ఉత్సవం',
    date: '2026-11-11',
    displayDate: 'Wednesday, 11th November 2026',
    time: '6:30 PM onwards',
    venue: 'The Grand Sapphire Ballroom',
    address: 'Sri Shubham Palace, Hyderabad',
    description: 'An unforgettable evening adorned with intricate henna designs, live dhol beats, family dance performances, cocktails, and a lavish royal dinner.',
    attire: 'Indo-Western Glamour, Vibrant Lehengas & Regal Kurta Sets',
    attireColorHint: '#10B981',
    iconName: 'Music',
    isMuhurtham: false
  },
  {
    id: 'snathakam',
    title: 'Snathakam & Sacred Pre-Wedding Rituals',
    teluguTitle: 'స్నాతకం & మంగళస్నానం',
    date: '2026-11-12',
    displayDate: 'Thursday, 12th November 2026',
    time: '4:30 PM to 6:30 PM',
    venue: 'Yajna Mandapam, Sri Shubham Palace',
    address: 'Sri Shubham Palace, Hyderabad',
    description: 'Traditional Vedic rites marking the groom and bride preparing for their sacred Grihastha Ashrama step with chanting of sacred mantras.',
    attire: 'Traditional Silk Pattu Vastra & Sarees',
    attireColorHint: '#D97706',
    iconName: 'Flame',
    isMuhurtham: false
  },
  {
    id: 'kalyanam',
    title: 'Sumuhurtham & Kalyana Mahotsavam',
    teluguTitle: 'శుభముహూర్తం & కల్యాణ మహోత్సవం',
    date: '2026-11-12',
    displayDate: 'Thursday, 12th November 2026',
    time: '7:30 PM onwards',
    muhurthamTime: '9:27 PM (Auspicious Jeelakarra-Bellam)',
    venue: 'Royal Swarna Kalyana Mandapam',
    address: 'Main Courtyard, Sri Shubham Palace, Hyderabad',
    description: 'The sacred moment of eternal union: Jeelakarra Bellam placement at the precise auspicious 9:27 PM Muhurtham, Mangalasutra Dharana, Talambralu, and Saptapadi around the holy fire.',
    attire: 'Regal Kanjeevaram Pattu Sarees, Silk Dhotis & Traditional Kurta Sets',
    attireColorHint: '#991B1B',
    iconName: 'HeartHandshake',
    isMuhurtham: true
  },
  {
    id: 'reception',
    title: 'Grand Wedding Reception',
    teluguTitle: 'మంగళ రిసెప్షన్ & విందు',
    date: '2026-11-13',
    displayDate: 'Friday, 13th November 2026',
    time: '7:00 PM onwards',
    venue: 'The Grand Imperial Lawn & Ballroom',
    address: 'Sri Shubham Palace, Hyderabad',
    description: 'Join the newlyweds for a grand evening of celebration, photo sessions, fellowship, and a magnificent celebratory banquet.',
    attire: 'Royal Evening Attire, Tuxedos, Sherwanis & Designer Gowns',
    attireColorHint: '#4338CA',
    iconName: 'Crown',
    isMuhurtham: false
  }
];

export const STORY_MILESTONES: StoryMilestone[] = [
  {
    yearOrPhase: 'The Serendipity',
    title: 'When Worlds Aligned',
    description: 'Introduced by dear family, our first conversation started as a brief hello and effortlessly turned into hours of shared laughter, values, and common dreams.',
    quote: '"From that very first conversation, every little detail just felt right."'
  },
  {
    yearOrPhase: 'The Connection',
    title: 'Conversations & Shared Passions',
    description: 'From evening coffee dates talking about literature, travel, and Telugu traditions, to discovering mutual love for South Indian filter coffee and sunsets.',
    quote: '"We found our safe harbor and biggest supporter in each other."'
  },
  {
    yearOrPhase: 'The Blessing',
    title: 'Two Families, One Heart',
    description: 'With the warm blessings of our parents and elders, the families came together in jubilation, officially sealing the engagement with joy and sweet mithai.',
    quote: '"Blessed by our roots, nurtured by love, ready for our lifetime."'
  },
  {
    yearOrPhase: 'The Sumuhurtham',
    title: 'Beginning of Forever',
    description: 'On 12 November 2026 at 9:27 PM, surrounded by our beloved family and friends, we take the seven sacred steps into eternity.',
    quote: '"We cannot wait to celebrate this divine milestone with you!"'
  }
];

export const INITIAL_BLESSINGS: Blessing[] = [
  {
    id: '1',
    name: 'Ramesh & Sunitha V.',
    relationOrCity: 'Family Friends, Hyderabad',
    message: 'Wishing Sushma & Sai Rahul a lifetime filled with deep companionship, radiant joy, and enduring prosperity. May Lord Venkateshwara bless this wonderful pair!',
    tag: '🪷 Mangalashasanam',
    timestamp: '2 hours ago',
    likes: 18
  },
  {
    id: '2',
    name: 'Kavitha Rao & Family',
    relationOrCity: 'Cousins, Bengaluru',
    message: 'So incredibly thrilled for you both! Sushma, you are going to look stunning in Kanjeevaram silk, and Sai Rahul, welcome to the family celebrations! Counting down to 12th Nov!',
    tag: '💐 Best Wishes',
    timestamp: '5 hours ago',
    likes: 24
  },
  {
    id: '3',
    name: 'Arjun & Neha',
    relationOrCity: 'Close Friends, Dallas',
    message: 'From college days to this auspicious Muhurtham! Heartiest congratulations Sai Rahul & Sushma. Looking forward to dancing our hearts out at the Sangeet!',
    tag: '✨ Eternal Love',
    timestamp: 'Yesterday',
    likes: 31
  },
  {
    id: '4',
    name: 'Venkata Sastry Garu',
    relationOrCity: 'Elder Blessing, Vijayawada',
    message: 'శుభమస్తు! మేమిద్దరికీ ఆయురారోగ్య ఐశ్వర్యాలు ప్రసాదించాలని కోరుకుంటున్నాము. సుముహూర్తాన జీలకర్ర-బెల్లం సమర్పించి సుఖసంతోషాలతో వర్ధిల్లాలి.',
    tag: '🪔 Shubh Vivah',
    timestamp: '2 days ago',
    likes: 42
  }
];
